package com.app.cooper.time_manager.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.app.cooper.time_manager.R;

public class CreditActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credit);
    }
}
